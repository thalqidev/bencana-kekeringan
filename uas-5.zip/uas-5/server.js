import express from "express";
import bodyParser from "body-parser";
import cors from "cors";

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

let reports = [];
let nextId = 1;

// ambil semua laporan
app.get("/api/reports", (req, res) => {
    res.json(reports);
}) ;

//tambah laporan
app.post("/api/reports", (req, res) => {
    const newReport = {id: nextId++,...req.body };
    reports.push(newReport);
    res.status(201).json(newReport);
    }) ;

    //edit laporan
    app.put("/api/reports/:id", (req, res) => {
        const id = parseInt(req.params.id);
        const index = reports.findIndex(report => report.id === id);
        if (index !== -1) {
            reports[index] = { ...reports[index], ...req.body };
            res.json(reports[index]);
            } else {
                res.status(404).json({ message: "Laporan tidak ditemukan" });
                }
                }) ;

    //hapus laporan
    app.delete("/api/reports/:id", (req, res) => {
        const id = parseInt(req.params.id);
        reports = reports.filter((report) => report.id !==id);
        res.status(204).send();
        }) ;

        app.listen(PORT, ()=>{
            console.log(`Server berjalan di http//localhost:${PORT}`);
        });