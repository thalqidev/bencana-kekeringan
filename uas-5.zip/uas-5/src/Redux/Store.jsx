import { configureStore } from "@reduxjs/toolkit";
import droughtSlice from "./droughtSlice";

const store = configureStore({
    reducer: {
        drought: droughtSlice,
    },
});

export default store;