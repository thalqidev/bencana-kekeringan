import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    report: []
};

const droughtSlice = createSlice({
    name: 'drought',
    initialState,
    reducers: {
        addReport:(state, action) => {
            state.report.push(action.payload);
        },
        deleteReport:(state, action) => {
            state.report = state.report.filter((report) => report.id !== action.payload);
        },
    },
});

export const { addReport, deleteReport } = droughtSlice.actions;
export default droughtSlice.reducer;