import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addReport, deleteReport } from '../Redux/droughtSlice';
import axios from "../service/axios";


function Dashboard(){
    const laporan = useSelector((state) => state.drought.reports);
    const dispatch = useDispatch();
    const [laporanBaru, setLaporanBaru] = useState({text: "", lokasi: "", tingkat: ""});
    const [LaporanEdit, setLaporanEdit] = useState(null);

    //ambil data laporan
    const ambilLaporan = async () => {
        try{
            const response = await axios.get("api/reports");
            response.data.for.Each((laporan) => dispatch(addReport(laporan)));
        } catch (error){
            console.error("Gagal mengambil data laporan",error);
        }
    };

    //tambah laporan
    const tambahLaporan = async () => {
        try{
            const response = await axios.post("api/reports", laporanBaru);
            dispatch(addReport(response.data));
            setLaporanBaru({text: "", lokasi: "", tingkat: ""});
        } catch(error) {
            console.error("Gagal menambahkan data laporan", error);
        }
    };

    //edit laporan
    const editLaporan = async (laporan) => {
        try{
            const response = await axios.put('api/reports/$LaporanEdit.id', laporanEdit);
            dispatch(deleteReport(laporanEdit.id));
            dispatch(addReport(response.data));
            setLaporanEdit(null);
        } catch (error) {
            console.error("Gagal mengedit data laporan", error);
        }
    };

    //hapus laporan
        const hapusLaporan = async (id) => {
            try{
                await axios.delete('api/reports/$(id)');
                dispatch(deleteReport(id));
            } catch (error) {
                console.error("Gagal menghapus data laporan", error);
            }
        };

        useEffect(() => {
            ambilLaporan();
        },[]);

        return (
            <div className='p-8'>
                <h1 className='text-3xl font-bold mb-4'>Dashboard pengelolaan bencana kekeringan</h1>

                <div className="mb-6 p-4 border rouded bg-gray-100">
                    <h2 className="text-xl font-semibold mb-4">Tambah Laporan Baru</h2>
                    <div className=" flex flex-col space-y-4">
                        <input type="text" value={laporanBaru.text} onChange={(e)=> setLaporanBaru({...laporanBaru, text:e.target.value})} placeholder='Deskripsi Laporan' className='p-2 border rounded'/>
                        <input type="text" value={laporanBaru.lokasi} onChange={(e) => setLaporanBaru({...laporanBaru, lokasi:e.target.value })} placeholder='Lokasi Laporan' className='p-2 border rounded'/>
                        <input type="text" value={laporanBaru.tingkat} onChange={(e) => setLaporanBaru({...laporanBaru, tingkat:e.target.value})} placeholder='Tingkat Keparahan (rendah, sedang, tinggi)' />
                        <button onClick={tambahLaporan} className='bg-blue-500 text-white px-4 py-2 rounded'>tambah laporan</button>
                    </div>
                </div>

                {laporanEdit && (
                    <div className="mb-6 p-4 border rounded bg-yellow-100">
                        <h2 className='text-xl font-semibold mmb-4'>edit laporan</h2>
                        <div className='flex flex-col space-y-4'>
                            <input type='text' value={laporanEdit.text} onChange={(e) => setLaporanEdit({...laporanEdit, text:e.target.value })} placeholder='Deskripsi Laporan' className='p-2 border rounded'/>
                            <input type='text' value={laporanEdit.lokasi} onChange={(e) => setLaporanEdit({...laporanEdit, lokasi:e.target.value })} placeholder='Lokasi' className='p-2 border rounded'/>
                            <input type='text' value={laporanEdit.tingkat} onChange={(e) => setLaporanEdit({...laporanEdit, tingkat:e.target.value })} placeholder='Tingkat Keparahan (rendah, sedang, tinggi)' className='p-2 border rounded'/>
                            <button onClick={simpanEditLaporan} className='bg-green-500 text-white px-4 py-2 rounded'>Simpan Perubahan</button>
                            <button onClick={()=> setLaporanEdit(null)} className='bg-red-500 text-white px-4 py-2 rounded'>Batal</button>
                        </div>
                    </div>
                )}

                <div className='overflow-x-auto'>
                    <h2 className='text-xl font-semibold mb-4'>Daftar Laporan</h2>
                    <table className='table-auto w-full border-collapse border border-fray-200'>
                        <thead>
                            <tr className='bg-gray-100'>
                                <th className='border p-2'>#</th>
                                <th className='border p-2'>Deskripsi</th>
                                <th className='border p-2'>Lokasi</th>
                                <th className='border p-2'>Tingkat</th>
                                <th className='border p-2'>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            {laporan.map((lap, index) => (
                                <tr key={lap.id} className='text-center'>
                                    <td className='border p-2'>{index + 1}</td>
                                    <td className='border p-2'>{lap.text}</td>
                                    <td className='border p-2'>{lap.lokasi}</td>
                                    <td className='border p-2'>{lap.tingkat}</td>
                                    <td className='border p-2 space-x-2'>
                                        <button onClick={() => setLaporanEdit(lap)} className='bg-ywllow-500 text-white px-2 py-1 rounded'>Edit</button>
                                        <button onClick={() => hapusLaporan(lap.id)} className='bg-red-500 text-white px-2 py-1 rounded'>Hpuas</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        );
}

export default Dashboard;