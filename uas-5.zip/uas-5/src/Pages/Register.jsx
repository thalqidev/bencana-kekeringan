import React from "react";
import { Link } from "react-router-dom";

function Register() {
    return (
        <div className="flex justify-center items-center min-h-screen bg-gray-100">
            <div className="bg-white p-8 rounded-lg shadow-mg w-96">
                <h2 className="text-2xl font-bold text-center mb-4">Register</h2>
                <form>
                    <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Full your name: </label>
                        <input type="text" className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"placeholder="Enter your full name"/>
                    </div>
                    <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Email: </label>
                        <input type="email" className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Enter your email" />
                    </div>
                    <div className="mb-4">
                        <label className="block text-sm font-medium mb-2">Password: </label>
                        <input type="text" className="py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Enter your password" />
                    </div>
                    <button type="suubmit" className="w-ful bg-green-500 text-white py-2 rounded-lg hover:bg-green-600">Register</button>
                </form>
                <p className="text-sm text-center mt-4">
                    Alreadt have an account?{""} 
                    <Link to="/" className="text-blue-500 hover:underline">Login</Link>
                </p>
            </div>
        </div>
    );
}

export default Register